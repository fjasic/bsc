var searchData=
[
  ['time',['time',['../namespacemain.html#a65b276856c7e6c8bbf750b0f5acf326e',1,'main']]],
  ['time_5fcan',['time_can',['../namespacemain.html#aa4f8e9bb313a3e8a7360883016936e83',1,'main']]],
  ['time_5fi2c',['time_i2c',['../namespacemain.html#a83748bb2294f90f52b22b1d38ad0fb64',1,'main']]],
  ['time_5fto_5fdecode',['time_to_decode',['../namespacemain.html#ac419b9ae651c025df2cd5ca5df1a6214',1,'main']]],
  ['time_5ftotal',['time_total',['../namespacemain.html#a30d308943cfbac0ea7067a496b870912',1,'main']]],
  ['to_5fsend',['to_send',['../namespacesend_s_p_i.html#a708e908a58064742e829fdb5fa459d7b',1,'sendSPI']]]
];
