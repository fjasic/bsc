var searchData=
[
  ['value',['value',['../namespacesend_i2_c.html#a520c30f4cf79020890e65e07bafa5944',1,'sendI2C']]],
  ['voltage',['voltage',['../namespacemain.html#a01aab34d0a91b33e540f12b3db3f3e09',1,'main']]],
  ['voltage_5ftotal',['voltage_total',['../namespacemain.html#aa0617577bd88f73d6312613e9f6c4b7f',1,'main']]]
];
