var searchData=
[
  ['file_5fto_5fopen',['file_to_open',['../namespacemain.html#ae79d34c7d6cee62c8a7b1d0cc02b7e91',1,'main']]],
  ['final_5fchecksum',['final_checksum',['../namespacemain.html#ae63e350198c042542d22ff6bfa5cd018',1,'main']]],
  ['final_5fparity',['final_parity',['../namespacemain.html#a1786bf64948c942db5302ad357c35486',1,'main']]]
];
