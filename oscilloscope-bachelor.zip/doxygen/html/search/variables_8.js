var searchData=
[
  ['max_5fspeed_5fhz',['max_speed_hz',['../namespacesend_s_p_i.html#a13ffdd2ff448bd9f912cae940a06b20f',1,'sendSPI']]]
];
