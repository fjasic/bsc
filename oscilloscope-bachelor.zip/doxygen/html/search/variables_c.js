var searchData=
[
  ['sample_5fperiod',['sample_period',['../namespacemain.html#af19346aa800bf78cae2d858965f36be6',1,'main']]],
  ['scl_5fi2c',['scl_i2c',['../namespacemain.html#ab8998d804d89305c0e16d5016f4763bf',1,'main']]],
  ['scl_5fto_5fdecode',['scl_to_decode',['../namespacemain.html#aa0ee83883e90bce37c53768eb07b590c',1,'main']]],
  ['sda_5fi2c',['sda_i2c',['../namespacemain.html#a7022b96b90a5873a76d777d54c6ed9ca',1,'main']]],
  ['sda_5fto_5fdecode',['sda_to_decode',['../namespacemain.html#a25f26d839220e12e3a5a24b50a34d19e',1,'main']]],
  ['spi',['spi',['../namespacesend_s_p_i.html#aeb66858101e3b12f213d88ffbdfad7bf',1,'sendSPI']]]
];
