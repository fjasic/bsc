var searchData=
[
  ['reader',['reader',['../namespacemain.html#a8c76b6c720bd89ac57607be7b89794b0',1,'main']]]
];
